package com.example.calculatorpart3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class Statistics : AppCompatActivity() {

    private val numbersArray = IntArray(10)
    private var numberOfNumbersEntered = 0

    private lateinit var numberEditText: EditText
    private lateinit var numbersTextView: TextView
    private lateinit var answerTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        numberEditText = findViewById(R.id.number1)
        numbersTextView = findViewById(R.id.tvNumberStored)
        answerTextView = findViewById(R.id.tvAnswer)

        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            addNumber()
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            clearNumbers()
        }

        findViewById<Button>(R.id.btnAverage).setOnClickListener {
            calculateAverage()
        }

        findViewById<Button>(R.id.btnMinMax).setOnClickListener {
            findMinMax()
        }
    }
    private fun addNumber() {
        // Check if the maximum number of allowed inputs is reached
        if (numberOfNumbersEntered < 10) {
            val enteredNumber = numberEditText.text.toString().toIntOrNull()

            // Check if a valid number is entered
            if (enteredNumber != null) {
                // Add the number to the array
                numbersArray[numberOfNumbersEntered] = enteredNumber

                // Increment the count of numbers entered
                numberOfNumbersEntered++

                // Update the displayed numbers
                updateNumbersTextView()
            } else {
                // Handle invalid input (non-numeric)
                // You may want to display an error message to the user
            }
        } else {
            // Handle case when the maximum number of inputs is reached
            // You may want to display a message to the user
        }
    }

    private fun clearNumbers() {
        // Reset array and counters
        numbersArray.fill(0)
        numberOfNumbersEntered = 0

        // Update the displayed numbers
        updateNumbersTextView()

        // Clear the answer TextView
        answerTextView.text = ""
    }

    private fun calculateAverage() {
        if (numberOfNumbersEntered > 0) {
            // Calculate the average using a loop
            var sum = 0
            for (i in 0 until numberOfNumbersEntered) {
                sum += numbersArray[i]
            }

            val average = sum.toDouble() / numberOfNumbersEntered

            // Display the average
            answerTextView.text = "Average: $average"
        } else {
            // Handle case when no numbers are entered
            // You may want to display a message to the user
        }
    }

    private fun findMinMax() {
        if (numberOfNumbersEntered > 0) {
            // Find the minimum and maximum using a loop
            var min = numbersArray[0]
            var max = numbersArray[0]

            for (i in 1 until numberOfNumbersEntered) {
                if (numbersArray[i] < min) {
                    min = numbersArray[i]
                }
                if (numbersArray[i] > max) {
                    max = numbersArray[i]
                }
            }

            // Display the minimum and maximum
            answerTextView.text = "Min: $min, Max: $max"
        } else {
            // Handle case when no numbers are entered
            // You may want to display a message to the user
        }
    }

    private fun updateNumbersTextView() {
        // Update the TextView with the numbers entered so far
        val displayedNumbers = numbersArray.copyOfRange(0, numberOfNumbersEntered)
        numbersTextView.text = displayedNumbers.joinToString(", ")
    }
}

